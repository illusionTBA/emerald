import React from 'react';

function Proxy(input) {
  return <div></div>;
}

export default Proxy;
